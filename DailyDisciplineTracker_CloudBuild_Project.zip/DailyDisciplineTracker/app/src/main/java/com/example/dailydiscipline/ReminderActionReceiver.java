package com.example.dailydiscipline;

import android.content.*;
import android.app.*;

public class ReminderActionReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent i) {
        String id=i.getStringExtra("habit_id");
        if(id==null)return;
        if("DONE".equals(i.getAction())){
            new HabitStore(c).setDone(id,true);
            NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
            if(nm!=null)nm.cancel(id.hashCode());
        } else if("LATER".equals(i.getAction())){
            Intent again=new Intent(c,ReminderReceiver.class).putExtra("habit_id",id);
            PendingIntent pi=PendingIntent.getBroadcast(c,id.hashCode()+3,again,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
            if(am!=null)am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,System.currentTimeMillis()+10*60*1000,pi);
        }
    }
}
