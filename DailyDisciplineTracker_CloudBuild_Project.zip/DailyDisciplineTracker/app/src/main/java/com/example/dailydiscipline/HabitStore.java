package com.example.dailydiscipline;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.*;

public class HabitStore {
    public static class Habit {
        public String id, name, doneDate;
        public int minuteOfDay; // -1 means no reminder
        Habit(String id, String name, int minuteOfDay, String doneDate) {
            this.id=id; this.name=name; this.minuteOfDay=minuteOfDay; this.doneDate=doneDate;
        }
        public boolean isDone(String today) { return today.equals(doneDate); }
    }

    private static final String PREF="daily_discipline";
    private static final String KEY="habits";
    private final SharedPreferences prefs;
    public HabitStore(Context c) {
        prefs=c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        if (!prefs.contains(KEY)) {
            ArrayList<Habit> defaults=new ArrayList<>();
            String[] names={
                "30 min of exercise.",
                "Skincare routine.",
                "Drink 2.5–3 litres of water.",
                "No tea.",
                "Focus on communication.",
                "Focus on skill development.",
                "No more than 30 min on social media.",
                "Read at least 10 pages of a book.",
                "Eat healthy and protein-rich food.",
                "Sleep for 7–8 hours.",
                "Practise gratitude.",
                "Plan the next day."
            };
            for (String n:names) defaults.add(new Habit(UUID.randomUUID().toString(),n,-1,""));
            save(defaults);
        }
    }
    public static String today() { return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date()); }
    public ArrayList<Habit> get() {
        ArrayList<Habit> out=new ArrayList<>();
        try {
            JSONArray a=new JSONArray(prefs.getString(KEY,"[]"));
            for(int i=0;i<a.length();i++){
                JSONObject o=a.getJSONObject(i);
                out.add(new Habit(o.getString("id"),o.getString("name"),o.optInt("minute",-1),o.optString("done","")));
            }
        } catch(Exception ignored) {}
        return out;
    }
    public void save(ArrayList<Habit> habits) {
        JSONArray a=new JSONArray();
        try {
            for(Habit h:habits){
                JSONObject o=new JSONObject();
                o.put("id",h.id); o.put("name",h.name); o.put("minute",h.minuteOfDay); o.put("done",h.doneDate);
                a.put(o);
            }
        } catch(Exception ignored) {}
        prefs.edit().putString(KEY,a.toString()).apply();
    }
    public void setDone(String id, boolean done) {
        ArrayList<Habit> hs=get();
        for(Habit h:hs) if(h.id.equals(id)) h.doneDate=done?today():"";
        save(hs);
    }
    public Habit find(String id) {
        for(Habit h:get()) if(h.id.equals(id)) return h;
        return null;
    }
}
