package com.example.dailydiscipline;

import android.app.*;
import android.content.*;
import android.os.Build;
import android.graphics.Color;

public class ReminderReceiver extends BroadcastReceiver {
    public static final String CHANNEL="habit_reminders";
    public static void schedule(Context c, HabitStore.Habit h) {
        cancel(c,h.id);
        if(h.minuteOfDay<0) return;
        java.util.Calendar cal=java.util.Calendar.getInstance();
        cal.set(java.util.Calendar.HOUR_OF_DAY,h.minuteOfDay/60);
        cal.set(java.util.Calendar.MINUTE,h.minuteOfDay%60);
        cal.set(java.util.Calendar.SECOND,0); cal.set(java.util.Calendar.MILLISECOND,0);
        if(cal.getTimeInMillis()<=System.currentTimeMillis()) cal.add(java.util.Calendar.DAY_OF_YEAR,1);
        Intent i=new Intent(c,ReminderReceiver.class).putExtra("habit_id",h.id);
        PendingIntent pi=PendingIntent.getBroadcast(c,h.id.hashCode(),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        if(am!=null){
            if(Build.VERSION.SDK_INT>=31 && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,cal.getTimeInMillis(),pi);
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,cal.getTimeInMillis(),pi);
            }
        }
    }
    public static void cancel(Context c,String id) {
        Intent i=new Intent(c,ReminderReceiver.class).putExtra("habit_id",id);
        PendingIntent pi=PendingIntent.getBroadcast(c,id.hashCode(),i,PendingIntent.FLAG_NO_CREATE|PendingIntent.FLAG_IMMUTABLE);
        if(pi!=null){ AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE); if(am!=null)am.cancel(pi); pi.cancel(); }
    }
    public static void rescheduleAll(Context c) {
        for(HabitStore.Habit h:new HabitStore(c).get()) schedule(c,h);
    }
    @Override public void onReceive(Context context, Intent intent) {
        String id=intent.getStringExtra("habit_id");
        if(id==null)return;
        HabitStore store=new HabitStore(context);
        HabitStore.Habit h=store.find(id);
        if(h==null || h.minuteOfDay<0)return;
        if(!h.isDone(HabitStore.today())) {
            createChannel(context);
            Intent open=new Intent(context,MainActivity.class);
            PendingIntent content=PendingIntent.getActivity(context,id.hashCode(),open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            Intent done=new Intent(context,ReminderActionReceiver.class).setAction("DONE").putExtra("habit_id",id);
            PendingIntent donePi=PendingIntent.getBroadcast(context,id.hashCode()+1,done,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            Intent later=new Intent(context,ReminderActionReceiver.class).setAction("LATER").putExtra("habit_id",id);
            PendingIntent laterPi=PendingIntent.getBroadcast(context,id.hashCode()+2,later,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(context,CHANNEL):new Notification.Builder(context);
            Notification n=b.setSmallIcon(android.R.drawable.checkbox_on_background)
                .setContentTitle("Daily Discipline")
                .setContentText("Time for: "+h.name)
                .setStyle(new Notification.BigTextStyle().bigText("Your scheduled habit is waiting: "+h.name))
                .setContentIntent(content).setAutoCancel(true)
                .addAction(android.R.drawable.checkbox_on_background,"Mark done",donePi)
                .addAction(android.R.drawable.ic_lock_idle_alarm,"Remind in 10 min",laterPi)
                .build();
            NotificationManager nm=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
            if(nm!=null)nm.notify(id.hashCode(),n);
        }
        schedule(context,h); // next day's reminder
    }
    public static void createChannel(Context c) {
        if(Build.VERSION.SDK_INT>=26){
            NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
            if(nm!=null && nm.getNotificationChannel(CHANNEL)==null){
                NotificationChannel ch=new NotificationChannel(CHANNEL,"Habit reminders",NotificationManager.IMPORTANCE_HIGH);
                ch.setDescription("Scheduled reminders for your daily habits");
                ch.enableVibration(true); ch.setLightColor(Color.GREEN);
                nm.createNotificationChannel(ch);
            }
        }
    }
}
