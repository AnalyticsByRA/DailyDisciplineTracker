package com.example.dailydiscipline;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.graphics.Typeface;
import android.graphics.Paint;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import android.text.InputType;
import java.util.*;

public class MainActivity extends Activity {
    private final int BG=Color.rgb(16,23,19), PANEL=Color.rgb(25,35,29), ROW=Color.rgb(32,44,36);
    private final int WHITE=Color.rgb(242,245,239), MUTED=Color.rgb(170,183,172), GREEN=Color.rgb(154,199,165);
    private HabitStore store; private LinearLayout list, root; private TextView progress, count; private ProgressBar progressBar; private int pad;
    @Override public void onCreate(Bundle b){
        super.onCreate(b); getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG);
        if(android.os.Build.VERSION.SDK_INT>=21) getWindow().getDecorView().setSystemUiVisibility(0);
        store=new HabitStore(this); pad=dp(16);
        ReminderReceiver.createChannel(this);
        requestNotificationPermission();
        build();
        ReminderReceiver.rescheduleAll(this);
    }
    private void requestNotificationPermission(){
        if(android.os.Build.VERSION.SDK_INT>=33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=android.content.pm.PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},10);
    }
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    private TextView text(String s,int size,int color,boolean bold){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return t;
    }
    private GradientDrawable bg(int color,int radius,int stroke){
        GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));
        if(stroke!=0)d.setStroke(dp(1),stroke);return d;
    }
    private LinearLayout vertical(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
    private LinearLayout horizontal(){LinearLayout l=new LinearLayout(this);l.setOrientation(0);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private void build(){
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(BG);
        root=vertical();root.setPadding(pad,dp(28),pad,dp(28));scroll.addView(root);
        TextView eyebrow=text("A DAILY PROMISE TO YOURSELF",11,GREEN,true);eyebrow.setGravity(Gravity.CENTER);root.addView(eyebrow);
        TextView title=text("1% BETTER EVERY DAY",27,WHITE,true);title.setGravity(Gravity.CENTER);LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,-2);tp.topMargin=dp(10);root.addView(title,tp);
        TextView sub=text("Small steps. Strong habits. Better me.",13,MUTED,false);sub.setGravity(Gravity.CENTER);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,-2);sp.topMargin=dp(5);sp.bottomMargin=dp(22);root.addView(sub,sp);
        LinearLayout card=vertical();card.setPadding(pad,pad,pad,pad);card.setBackground(bg(PANEL,22,Color.rgb(43,58,49)));root.addView(card);
        LinearLayout top=horizontal();top.addView(text("TODAY'S PROGRESS",12,MUTED,true),new LinearLayout.LayoutParams(0,-2,1));
        progress=text("0%",24,GREEN,true);top.addView(progress);card.addView(top);
        progressBar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);progressBar.setMax(100);progressBar.setProgressTintList(android.content.res.ColorStateList.valueOf(GREEN));progressBar.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(51,66,57)));LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,dp(8));bp.topMargin=dp(10);card.addView(progressBar,bp);
        count=text("0 completed",12,MUTED,false);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.topMargin=dp(8);card.addView(count,cp);
        LinearLayout header=horizontal();LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,-2);hp.topMargin=dp(22);hp.bottomMargin=dp(10);root.addView(header,hp);
        header.addView(text("MY DAILY HABITS",12,MUTED,true),new LinearLayout.LayoutParams(0,-2,1));
        Button add=button("+ Add habit");add.setOnClickListener(v->editHabit(null));header.addView(add);
        list=vertical();root.addView(list);
        TextView foot=text("Consistency over perfection.",12,MUTED,false);foot.setGravity(Gravity.CENTER);LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(-1,-2);fp.topMargin=dp(22);root.addView(foot,fp);
        setContentView(scroll);render();
    }
    private Button button(String label){
        Button b=new Button(this);b.setText(label);b.setTextSize(12);b.setAllCaps(false);b.setTextColor(GREEN);
        b.setPadding(dp(10),0,dp(10),0);b.setBackground(bg(ROW,30,Color.rgb(82,105,88)));return b;
    }
    private void render(){
        list.removeAllViews();ArrayList<HabitStore.Habit> hs=store.get();int done=0;
        for(HabitStore.Habit h:hs)if(h.isDone(HabitStore.today()))done++;
        int pct=hs.isEmpty()?0:Math.round(done*100f/hs.size());
        progress.setText(pct+"%");count.setText(done+" of "+hs.size()+" completed");
        progressBar.setProgress(pct);
        for(HabitStore.Habit h:hs){
            LinearLayout row=horizontal();row.setPadding(dp(10),dp(8),dp(8),dp(8));row.setBackground(bg(ROW,14,Color.rgb(48,64,54)));
            LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.bottomMargin=dp(8);list.addView(row,rp);
            CheckBox cb=new CheckBox(this);cb.setButtonTintList(new android.content.res.ColorStateList(new int[][]{new int[]{android.R.attr.state_checked},new int[]{}},new int[]{GREEN,MUTED}));
            cb.setChecked(h.isDone(HabitStore.today()));row.addView(cb);
            TextView name=text(h.name,14,WHITE,false);name.setGravity(Gravity.CENTER_VERTICAL);name.setPaintFlags(h.isDone(HabitStore.today())?name.getPaintFlags()|Paint.STRIKE_THRU_TEXT_FLAG:name.getPaintFlags()&~Paint.STRIKE_THRU_TEXT_FLAG);
            row.addView(name,new LinearLayout.LayoutParams(0,-2,1));
            cb.setOnCheckedChangeListener((button,checked)->{store.setDone(h.id,checked);render();});
            LinearLayout actions=vertical();
            Button time=button(h.minuteOfDay<0?"Set time":String.format(Locale.US,"%02d:%02d",h.minuteOfDay/60,h.minuteOfDay%60));
            time.setOnClickListener(vv->pickTime(h));
            time.setOnLongClickListener(vv->{
                new AlertDialog.Builder(this).setTitle("Remove reminder?")
                    .setMessage("Turn off the daily reminder for this activity?")
                    .setNegativeButton("Keep",null).setPositiveButton("Turn off",(dd,ww)->{
                        ArrayList<HabitStore.Habit> hs2=store.get();
                        for(HabitStore.Habit x:hs2)if(x.id.equals(h.id))x.minuteOfDay=-1;
                        store.save(hs2);ReminderReceiver.cancel(this,h.id);render();
                    }).show(); return true;
            });
            actions.addView(time);
            Button edit=button("Edit");LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(-1,dp(38));ep.topMargin=dp(4);actions.addView(edit,ep);edit.setOnClickListener(vv->editHabit(h));
            row.addView(actions);
        }
    }
    private void pickTime(HabitStore.Habit h){
        Calendar c=Calendar.getInstance();int hr=h.minuteOfDay<0?c.get(Calendar.HOUR_OF_DAY):h.minuteOfDay/60;int min=h.minuteOfDay<0?0:h.minuteOfDay%60;
        new TimePickerDialog(this,(view,hour,minute)->{ArrayList<HabitStore.Habit> hs=store.get();for(HabitStore.Habit x:hs)if(x.id.equals(h.id))x.minuteOfDay=hour*60+minute;store.save(hs);ReminderReceiver.schedule(this,store.find(h.id));render();},hr,min,false).show();
    }
    private void editHabit(HabitStore.Habit existing){
        final EditText input=new EditText(this);input.setSingleLine(false);input.setTextColor(WHITE);input.setHintTextColor(MUTED);input.setHint("Activity name");input.setText(existing==null?"":existing.name);
        LinearLayout box=vertical();box.setPadding(dp(20),dp(8),dp(20),0);box.addView(input);
        AlertDialog.Builder builder=new AlertDialog.Builder(this).setTitle(existing==null?"Add activity":"Edit activity").setView(box)
            .setNegativeButton("Cancel",null).setPositiveButton("Save",(d,w)->{
                String name=input.getText().toString().trim();if(name.isEmpty())return;
                ArrayList<HabitStore.Habit> hs=store.get();
                if(existing==null)hs.add(new HabitStore.Habit(UUID.randomUUID().toString(),name,-1,""));
                else for(HabitStore.Habit h:hs)if(h.id.equals(existing.id))h.name=name;
                store.save(hs);if(existing!=null)ReminderReceiver.schedule(this,store.find(existing.id));render();
            });
        if(existing!=null)builder.setNeutralButton("Delete",(d,w)->{
            ArrayList<HabitStore.Habit> hs=store.get();hs.removeIf(h->h.id.equals(existing.id));store.save(hs);ReminderReceiver.cancel(this,existing.id);render();
        });
        builder.show();
    }
}
