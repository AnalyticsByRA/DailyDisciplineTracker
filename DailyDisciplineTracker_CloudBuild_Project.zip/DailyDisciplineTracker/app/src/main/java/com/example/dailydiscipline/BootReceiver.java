package com.example.dailydiscipline;
import android.content.*;
public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent i) { ReminderReceiver.rescheduleAll(c); }
}
