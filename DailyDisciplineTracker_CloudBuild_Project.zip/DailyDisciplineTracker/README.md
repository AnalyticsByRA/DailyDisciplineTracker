# Daily Discipline Tracker (Android source project)

This is a native Android starter project for the Daily Discipline habit tracker.

## Features
- Dark-mode native Android interface
- Add, edit, and delete habits
- Daily completion checkboxes and progress percentage
- Optional per-habit daily reminder time
- Notification actions: Mark done / Remind in 10 minutes
- Local persistence with SharedPreferences
- Re-schedules reminders after device reboot

## Build an APK
1. Install Android Studio on a computer.
2. Open this folder as an existing Android Studio project.
3. Allow Gradle to sync and install Android SDK Platform 35 if prompted.
4. Connect a device or use an emulator and press Run.
5. To create an installable APK, choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Android Studio will show the generated APK location (usually `app/build/outputs/apk/debug/app-debug.apk`).

## Important OPPO Reno7 Pro / ColorOS 13 setup
- Allow notifications for Daily Discipline.
- In Settings > Apps > Special app access, allow exact alarms if the OS asks.
- In battery settings, set the app to allow background activity / don't optimise it if reminders are delayed.
- Lock-screen notification visibility depends on your lock-screen privacy settings.
- Android does not allow a third-party app to place arbitrary tappable controls directly over the secure lock screen. Notification action buttons are shown in the notification shade / lock-screen notification card when permitted by ColorOS.

## Notes
- Reminders are optional and are disabled until a time is set for a habit.
- The initial default habit list matches the requested checklist.
- This project source has not been compiled in this environment. Android Studio must build and sign the APK.


## Build the APK in the cloud (no Android Studio required on your phone)

This project includes a GitHub Actions workflow. It builds a debug APK and makes it available as a downloadable artifact.

1. Create a GitHub account if you do not already have one.
2. On GitHub, create a new **public or private** repository named `DailyDisciplineTracker`.
3. Upload the contents of this project folder to the repository (the `app`, `.github`, and Gradle files must be at the repository root).
4. Open the repository's **Actions** tab and select **Build Daily Discipline APK**. If needed, tap **Run workflow**.
5. Wait for the workflow to finish with a green check mark. Open that completed run and download the `Daily-Discipline-debug-APK` artifact.
6. Extract the downloaded artifact ZIP on your phone and install `app-debug.apk`. Android may ask you to allow installs from the browser or file manager you used.

The generated debug APK is signed with the standard debug key and is suitable for personal testing. It is not a Play Store release build. The workflow has been prepared but has not been run from this environment, so the APK still needs to be built by GitHub Actions.
